#!/usr/bin/env python3
"""Install the bundled skill without overwriting an existing installation."""
import argparse
import os
import shutil
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--platform', choices=['codex', 'claude'], default='codex')
    parser.add_argument('--target', type=Path, help='自訂 skills 根資料夾')
    args = parser.parse_args()
    source = Path(__file__).resolve().parent / 'six-p-product-handbook'
    if not (source / 'SKILL.md').is_file():
        parser.error('找不到技能資料夾，請先完整解壓安裝包')
    base = args.target
    if base is None:
        base = ((Path(os.environ.get('CODEX_HOME', str(Path.home() / '.codex'))) / 'skills')
                if args.platform == 'codex' else Path.home() / '.claude' / 'skills')
    target = base.expanduser().resolve() / source.name
    if target.exists():
        parser.error('目標已存在，不覆寫；請先保留舊版或指定另一個 --target')
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, target, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.DS_Store'))
    print('已安裝：' + str(target))
    print('重新開啟 AI 工作階段，再輸入：請用 six-p-product-handbook 訪談我並做產品手冊。')


if __name__ == '__main__':
    main()
